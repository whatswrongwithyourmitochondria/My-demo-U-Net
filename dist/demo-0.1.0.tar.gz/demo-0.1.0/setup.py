# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['demo']
install_requires = \
['numpy>=1.22.2,<1.23.0',
 'opencv-python>=4.5.5,<4.6.0',
 'tensorflow>=2.8.0,<2.9.0']

setup_kwargs = {
    'name': 'demo',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Maria Batrakova',
    'author_email': 'simmura@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.9',
}


setup(**setup_kwargs)
